// var num=10;
// console.log(num);
//ARRAY
let arr=["Suryansh",17,true,null];
arr.forEach((nums)=>{
    console.log(nums);
});
// MAP--
let arr1=[10,20,30,40]
let newarr=arr1.map((nums)=>nums*2);
console.log(arr1);
console.log(newarr);

let names=["Riya","Hricha"]
let capnames=names.map((name)=>name.toUpperCase());
console.log(names);
console.log(capnames);
// // filter()
// // reduce()---
let accm=arr1.reduce((nums,acc)=>nums+acc,0)
console.log(accm);